'use client'

import { useState } from 'react'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Upload, CheckCircle2, Clock } from 'lucide-react'

const interiorTasks = [
  { name: 'Electrical Installation', progress: 75, status: 'in-progress' },
  { name: 'Plumbing Installation', progress: 60, status: 'in-progress' },
  { name: 'HVAC', progress: 45, status: 'in-progress' },
  { name: 'Gypsum & Interior Plaster', progress: 30, status: 'in-progress' },
  { name: 'Flooring & Tiling', progress: 0, status: 'not-started' },
  { name: 'Interior Doors', progress: 0, status: 'not-started' },
  { name: 'Kitchen Cabinets', progress: 0, status: 'not-started' },
  { name: 'Bathroom Fixtures', progress: 0, status: 'not-started' },
  { name: 'Final Painting', progress: 0, status: 'not-started' },
]

const pastSubmissions = [
  {
    id: 1,
    task: 'Electrical Installation',
    villa: 'A-101',
    timestamp: '2 hours ago',
    status: 'approved',
  },
  {
    id: 2,
    task: 'Plumbing Installation',
    villa: 'A-101',
    timestamp: '5 hours ago',
    status: 'approved',
  },
  {
    id: 3,
    task: 'HVAC',
    villa: 'A-101',
    timestamp: '1 day ago',
    status: 'pending',
  },
]

export default function WorkerPage() {
  const [open, setOpen] = useState(false)
  const [project, setProject] = useState('')
  const [villa, setVilla] = useState('')
  const [task, setTask] = useState('')
  const [notes, setNotes] = useState('')
  const [files, setFiles] = useState<File[]>([])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files))
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Mock submission - would upload to backend in production
    console.log({ project, villa, task, notes, files })
    setOpen(false)
    // Reset form
    setProject('')
    setVilla('')
    setTask('')
    setNotes('')
    setFiles([])
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8 px-6 space-y-8">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-foreground">My Tasks</h1>
          <p className="text-muted-foreground">Submit completion proof for your assigned interior tasks</p>
        </div>

        {/* Interior Tasks */}
        <Card className="border-border/50 shadow-xl">
          <CardHeader>
            <CardTitle>Interior Tasks - Villa A-101</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {interiorTasks.map((task, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 border border-border/50 rounded-xl hover:border-accent/50 transition-colors"
              >
                <div className="flex-1 space-y-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-1.5 rounded-full ${
                        task.status === 'in-progress'
                          ? 'bg-secondary/20'
                          : 'bg-muted'
                      }`}
                    >
                      {task.status === 'in-progress' ? (
                        <Clock className="w-4 h-4 text-secondary" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-muted-foreground" />
                      )}
                    </div>
                    <h4 className="font-semibold text-foreground">{task.name}</h4>
                  </div>
                  <div className="flex items-center gap-4 ml-10">
                    <Progress value={task.progress} className="h-2 flex-1 max-w-md" />
                    <span className="text-sm font-semibold text-muted-foreground min-w-12">
                      {task.progress}%
                    </span>
                  </div>
                </div>

                <Dialog open={open} onOpenChange={setOpen}>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="gap-2 border-accent text-accent hover:bg-accent hover:text-accent-foreground"
                    >
                      <Upload className="w-4 h-4" />
                      Submit Proof
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Submit Completion Proof</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Project *</Label>
                          <Select value={project} onValueChange={setProject} required>
                            <SelectTrigger>
                              <SelectValue placeholder="Select project" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="sedra">SEDRA</SelectItem>
                              <SelectItem value="al-waha">AL WAHA</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label>Villa *</Label>
                          <Select value={villa} onValueChange={setVilla} required>
                            <SelectTrigger>
                              <SelectValue placeholder="Select villa" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="A-101">A-101</SelectItem>
                              <SelectItem value="A-102">A-102</SelectItem>
                              <SelectItem value="A-103">A-103</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Task Type *</Label>
                        <Select value={task} onValueChange={setTask} required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select task" />
                          </SelectTrigger>
                          <SelectContent>
                            {interiorTasks.map((t, i) => (
                              <SelectItem key={i} value={t.name}>
                                {t.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Upload Photos (1-5 images) *</Label>
                        <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-accent transition-colors cursor-pointer">
                          <input
                            type="file"
                            multiple
                            accept="image/*"
                            onChange={handleFileChange}
                            className="hidden"
                            id="file-upload"
                            required
                          />
                          <label htmlFor="file-upload" className="cursor-pointer space-y-2">
                            <Upload className="w-8 h-8 mx-auto text-muted-foreground" />
                            <p className="text-sm text-muted-foreground">
                              Click to upload or drag and drop
                            </p>
                            {files.length > 0 && (
                              <p className="text-sm font-medium text-accent">
                                {files.length} file(s) selected
                              </p>
                            )}
                          </label>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Notes</Label>
                        <Textarea
                          placeholder="Add any notes about the work completed..."
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          rows={3}
                        />
                      </div>

                      <div className="flex gap-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setOpen(false)}
                          className="flex-1"
                        >
                          Cancel
                        </Button>
                        <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90">
                          Submit
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Past Submissions */}
        <Card className="border-border/50 shadow-xl">
          <CardHeader>
            <CardTitle>Past Submissions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {pastSubmissions.map((submission) => (
              <div
                key={submission.id}
                className="flex items-center justify-between p-4 border border-border/50 rounded-xl"
              >
                <div className="space-y-1">
                  <h4 className="font-semibold text-foreground">{submission.task}</h4>
                  <p className="text-sm text-muted-foreground">
                    Villa {submission.villa} • {submission.timestamp}
                  </p>
                </div>
                <Badge
                  variant={submission.status === 'approved' ? 'default' : 'secondary'}
                  className={
                    submission.status === 'approved'
                      ? 'bg-accent/10 text-accent'
                      : 'bg-chart-3/10 text-chart-3'
                  }
                >
                  {submission.status === 'approved' ? 'Approved' : 'Pending Review'}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
