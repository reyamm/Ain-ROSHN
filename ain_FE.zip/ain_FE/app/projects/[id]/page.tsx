'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { ArrowLeft, Building2, Search } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

const villas = [
  { id: 'A-101', type: 'A', progress: 85, status: 'on-track', completion: '2024-03-15' },
  { id: 'A-102', type: 'A', progress: 72, status: 'on-track', completion: '2024-03-20' },
  { id: 'A-103', type: 'A', progress: 45, status: 'at-risk', completion: '2024-04-10' },
  { id: 'A-104', type: 'A', progress: 28, status: 'delayed', completion: '2024-04-25' },
  { id: 'B-201', type: 'B', progress: 90, status: 'on-track', completion: '2024-03-10' },
  { id: 'B-202', type: 'B', progress: 63, status: 'on-track', completion: '2024-03-28' },
]

export default function ProjectDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState('')
  const [filterType, setFilterType] = useState('all')
  const [filterStatus, setFilterStatus] = useState('all')

  const filteredVillas = villas.filter((villa) => {
    const matchesSearch = villa.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = filterType === 'all' || villa.type === filterType
    const matchesStatus = filterStatus === 'all' || villa.status === filterStatus
    return matchesSearch && matchesType && matchesStatus
  })

  const completedVillas = villas.filter((v) => v.progress === 100).length
  const delayedVillas = villas.filter((v) => v.status === 'delayed').length
  const inProgressVillas = villas.filter((v) => v.progress > 0 && v.progress < 100).length

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8 px-6 space-y-8">
        <Button
          variant="ghost"
          onClick={() => router.push('/dashboard')}
          className="gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Button>

        {/* Project Header */}
        <div className="space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <h1 className="text-4xl font-bold text-foreground">Project 1 / SEDRA</h1>
              <p className="text-muted-foreground flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                Riyadh, Saudi Arabia
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <Card className="flex-1 border-border/50 shadow-md">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-accent">{completedVillas}</div>
                <div className="text-sm text-muted-foreground">Villas Completed</div>
              </CardContent>
            </Card>
            <Card className="flex-1 border-border/50 shadow-md">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-destructive">{delayedVillas}</div>
                <div className="text-sm text-muted-foreground">Villas Delayed</div>
              </CardContent>
            </Card>
            <Card className="flex-1 border-border/50 shadow-md">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-secondary">{inProgressVillas}</div>
                <div className="text-sm text-muted-foreground">Villas In Progress</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Filters */}
        <Card className="border-border/50 shadow-md">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search Villa ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-11"
                />
              </div>

              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Villa Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="A">Type A</SelectItem>
                  <SelectItem value="B">Type B</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="on-track">On Track</SelectItem>
                  <SelectItem value="at-risk">At Risk</SelectItem>
                  <SelectItem value="delayed">Delayed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Villas Table */}
        <Card className="border-border/50 shadow-xl">
          <CardContent className="p-6">
            <div className="space-y-4">
              {/* Table Header */}
              <div className="grid grid-cols-12 gap-4 pb-3 border-b border-border text-sm font-semibold text-muted-foreground">
                <div className="col-span-2">Villa ID</div>
                <div className="col-span-2">Villa Type</div>
                <div className="col-span-4">Progress</div>
                <div className="col-span-2">Status</div>
                <div className="col-span-2">Est. Completion</div>
              </div>

              {/* Table Rows */}
              {filteredVillas.map((villa) => (
                <div
                  key={villa.id}
                  className="grid grid-cols-12 gap-4 py-4 border-b border-border/50 items-center hover:bg-accent/5 cursor-pointer transition-colors rounded-lg px-2"
                  onClick={() => router.push(`/villas/${villa.id}`)}
                >
                  <div className="col-span-2 font-semibold text-foreground">{villa.id}</div>
                  <div className="col-span-2 text-muted-foreground">Type {villa.type}</div>
                  <div className="col-span-4 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <Progress value={villa.progress} className="h-2 flex-1 mr-3" />
                      <span className="font-semibold text-foreground min-w-12 text-right">
                        {villa.progress}%
                      </span>
                    </div>
                  </div>
                  <div className="col-span-2">
                    <Badge
                      variant={villa.status === 'on-track' ? 'default' : 'destructive'}
                      className={
                        villa.status === 'on-track'
                          ? 'bg-accent/10 text-accent hover:bg-accent/20'
                          : villa.status === 'at-risk'
                          ? 'bg-chart-3/10 text-chart-3 hover:bg-chart-3/20'
                          : 'bg-destructive/10 text-destructive hover:bg-destructive/20'
                      }
                    >
                      {villa.status === 'on-track'
                        ? 'On Track'
                        : villa.status === 'at-risk'
                        ? 'At Risk'
                        : 'Delayed'}
                    </Badge>
                  </div>
                  <div className="col-span-2 text-sm text-muted-foreground">{villa.completion}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
