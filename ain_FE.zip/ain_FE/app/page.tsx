'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Building2, Eye, EyeOff } from 'lucide-react'

export default function LoginPage() {
  const router = useRouter()
  const [userType, setUserType] = useState<'manager' | 'worker'>('manager')
  const [showPassword, setShowPassword] = useState(false)
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // Mock login - in production this would validate credentials
    if (userType === 'manager') {
      router.push('/dashboard')
    } else {
      router.push('/worker')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-accent/5 p-4">
      <div className="w-full max-w-5xl grid lg:grid-cols-5 bg-card rounded-3xl shadow-2xl overflow-hidden">
        {/* Left Panel - Brand */}
        <div className="lg:col-span-2 bg-gradient-to-br from-primary via-primary/95 to-primary/90 p-12 flex flex-col justify-between text-primary-foreground">
          <div className="space-y-8">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-accent rounded-2xl">
                <Building2 className="w-8 h-8 text-accent-foreground" />
              </div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">AIN ROSHEN</h1>
                <p className="text-sm text-primary-foreground/80">Construction Intelligence</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <h2 className="text-4xl font-bold leading-tight text-balance">
                Your Site. Your Visibility.
              </h2>
              <p className="text-primary-foreground/90 leading-relaxed text-balance">
                From structural to finishing stages, AIN highlights what's done, ongoing, and delayed—helping teams build confidently.
              </p>
            </div>
          </div>

          <div className="space-y-2 text-sm text-primary-foreground/70">
            <p>© 2025 ROSHEN. All rights reserved.</p>
            <p>Contact: +966 11 234 5678</p>
          </div>
        </div>

        {/* Right Panel - Login Form */}
        <div className="lg:col-span-3 p-12">
          <div className="max-w-md mx-auto space-y-8">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold text-foreground">Welcome back</h2>
              <p className="text-muted-foreground">
                Login to monitor construction projects in real time
              </p>
            </div>

            {/* User Type Toggle */}
            <div className="flex gap-2 p-1 bg-muted rounded-xl">
              <button
                type="button"
                onClick={() => setUserType('manager')}
                className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                  userType === 'manager'
                    ? 'bg-card shadow-md text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Manager
              </button>
              <button
                type="button"
                onClick={() => setUserType('worker')}
                className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                  userType === 'worker'
                    ? 'bg-card shadow-md text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Worker
              </button>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+966 XX XXX XXXX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="h-12"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-12 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="button"
                  className="text-sm text-accent hover:text-accent/80 font-medium"
                >
                  Forgot your password?
                </button>
              </div>

              <Button type="submit" className="w-full h-12 text-base font-semibold bg-primary hover:bg-primary/90">
                Sign In
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
