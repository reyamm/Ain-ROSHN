'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, FileText, AlertTriangle, Cloud, Clock, CheckCircle2, Circle, ImageIcon } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

const externalPhases = [
  { name: 'Site Preparation', expected: 5, actual: 5, status: 'completed' },
  { name: 'Foundations', expected: 12, actual: 14, status: 'completed-delayed' },
  { name: 'Structural Frame', expected: 18, actual: 16, status: 'in-progress' },
  { name: 'Envelope / External Walls', expected: 10, actual: 0, status: 'upcoming' },
  { name: 'Exterior Finishing & Landscaping', expected: 8, actual: 0, status: 'upcoming' },
]

const interiorTasks = [
  { name: 'Electrical Installation', progress: 75 },
  { name: 'Plumbing Installation', progress: 60 },
  { name: 'HVAC', progress: 45 },
  { name: 'Gypsum & Interior Plaster', progress: 30 },
  { name: 'Flooring & Tiling', progress: 0 },
  { name: 'Interior Doors', progress: 0 },
  { name: 'Kitchen Cabinets', progress: 0 },
  { name: 'Bathroom Fixtures', progress: 0 },
  { name: 'Final Painting', progress: 0 },
]

const progressFeed = [
  {
    id: 1,
    task: 'Electrical Installation',
    status: 'In Progress',
    notes: 'First floor wiring completed',
    timestamp: '2h ago',
    image: '/exposed-electrical-wiring.png',
  },
  {
    id: 2,
    task: 'Plumbing Installation',
    status: 'Completed',
    notes: 'All bathroom rough-in complete',
    timestamp: '5h ago',
    image: '/plumbing-pipes.png',
  },
  {
    id: 3,
    task: 'HVAC',
    status: 'In Progress',
    notes: 'Ductwork installation ongoing',
    timestamp: '1d ago',
    image: '/hvac-ducts.jpg',
  },
]

export default function VillaDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8 px-6 space-y-8">
        <Button
          variant="ghost"
          onClick={() => router.push('/projects/1')}
          className="gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Project
        </Button>

        {/* Villa Header */}
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold text-foreground">Villa #{params.id}</h1>
            <p className="text-muted-foreground">Project SEDRA / Riyadh</p>
          </div>
          <Button className="gap-2 bg-primary hover:bg-primary/90">
            <FileText className="w-4 h-4" />
            Generate Report
          </Button>
        </div>

        {/* Progress Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-border/50 shadow-md">
            <CardContent className="p-6 text-center space-y-2">
              <div className="text-3xl font-bold text-foreground">33%</div>
              <div className="text-sm font-medium text-muted-foreground">Overall Progress</div>
            </CardContent>
          </Card>
          <Card className="border-border/50 shadow-md">
            <CardContent className="p-6 text-center space-y-2">
              <div className="text-3xl font-bold text-accent">2/5</div>
              <div className="text-sm font-medium text-muted-foreground">External Phases</div>
            </CardContent>
          </Card>
          <Card className="border-border/50 shadow-md">
            <CardContent className="p-6 text-center space-y-2">
              <div className="text-3xl font-bold text-secondary">3/9</div>
              <div className="text-sm font-medium text-muted-foreground">Internal Tasks</div>
            </CardContent>
          </Card>
          <Card className="border-border/50 shadow-md">
            <CardContent className="p-6 text-center space-y-2">
              <div className="text-3xl font-bold text-chart-3">2</div>
              <div className="text-sm font-medium text-muted-foreground">Warning Alerts</div>
            </CardContent>
          </Card>
        </div>

        {/* Alerts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="border-l-4 border-l-chart-3 bg-chart-3/5">
            <CardContent className="p-6">
              <div className="flex gap-4">
                <div className="p-2 bg-chart-3/20 rounded-lg h-fit">
                  <Cloud className="w-5 h-5 text-chart-3" />
                </div>
                <div className="space-y-2 flex-1">
                  <div className="flex items-start justify-between">
                    <h4 className="font-semibold text-foreground">Weather Alert</h4>
                    <span className="text-xs text-muted-foreground">2h ago</span>
                  </div>
                  <p className="text-sm text-foreground/80">
                    Heavy rain expected tomorrow. Concrete curing may extend by 2-3 days.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-destructive bg-destructive/5">
            <CardContent className="p-6">
              <div className="flex gap-4">
                <div className="p-2 bg-destructive/20 rounded-lg h-fit">
                  <AlertTriangle className="w-5 h-5 text-destructive" />
                </div>
                <div className="space-y-2 flex-1">
                  <div className="flex items-start justify-between">
                    <h4 className="font-semibold text-foreground">Phase Delay Alert</h4>
                    <span className="text-xs text-muted-foreground">5d ago</span>
                  </div>
                  <p className="text-sm text-foreground/80">
                    Foundations phase exceeded expected timeline by 2 days.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* External Phases Timeline */}
        <Card className="border-border/50 shadow-xl">
          <CardHeader>
            <CardTitle>Construction Phases (External)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {externalPhases.map((phase, index) => (
              <div key={index} className="flex items-center gap-6">
                <div className="flex flex-col items-center">
                  {phase.status === 'completed' || phase.status === 'completed-delayed' ? (
                    <div className="p-2 bg-accent rounded-full">
                      <CheckCircle2 className="w-5 h-5 text-accent-foreground" />
                    </div>
                  ) : phase.status === 'in-progress' ? (
                    <div className="p-2 bg-secondary rounded-full">
                      <Clock className="w-5 h-5 text-secondary-foreground" />
                    </div>
                  ) : (
                    <div className="p-2 bg-muted rounded-full">
                      <Circle className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}
                  {index < externalPhases.length - 1 && (
                    <div className="w-0.5 h-12 bg-border mt-2" />
                  )}
                </div>

                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-foreground">{phase.name}</h4>
                    <Badge
                      variant={
                        phase.status === 'completed'
                          ? 'default'
                          : phase.status === 'completed-delayed'
                          ? 'destructive'
                          : phase.status === 'in-progress'
                          ? 'secondary'
                          : 'outline'
                      }
                      className={
                        phase.status === 'completed'
                          ? 'bg-accent/10 text-accent'
                          : phase.status === 'completed-delayed'
                          ? 'bg-chart-3/10 text-chart-3'
                          : phase.status === 'in-progress'
                          ? 'bg-secondary/10 text-secondary'
                          : ''
                      }
                    >
                      {phase.status === 'completed'
                        ? 'Completed'
                        : phase.status === 'completed-delayed'
                        ? `Completed (+${phase.actual - phase.expected}d)`
                        : phase.status === 'in-progress'
                        ? 'In Progress'
                        : 'Upcoming'}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Expected: {phase.expected} days
                    {phase.actual > 0 && ` • Actual: ${phase.actual} days`}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Interior Tasks */}
          <Card className="border-border/50 shadow-xl">
            <CardHeader>
              <CardTitle>Interior Tasks</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {interiorTasks.map((task, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium text-foreground">{task.name}</span>
                    <span className="text-muted-foreground font-semibold">{task.progress}%</span>
                  </div>
                  <Progress value={task.progress} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Predictive Model */}
          <Card className="border-border/50 shadow-xl">
            <CardHeader>
              <CardTitle>ML Prediction Model</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-border">
                  <span className="text-sm text-muted-foreground">Estimated Duration</span>
                  <span className="text-2xl font-bold text-accent">13.1 months</span>
                </div>
                <div className="flex items-center justify-between pb-3 border-b border-border">
                  <span className="text-sm text-muted-foreground">Predicted Completion</span>
                  <span className="font-semibold text-foreground">May 15, 2024</span>
                </div>
              </div>

              <div className="space-y-3 pt-4">
                <h4 className="text-sm font-semibold text-foreground uppercase tracking-wide">
                  Model Inputs
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <div className="text-xs text-muted-foreground">Area</div>
                    <div className="font-semibold text-foreground">250 sqm</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-xs text-muted-foreground">Floors</div>
                    <div className="font-semibold text-foreground">2</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-xs text-muted-foreground">Rooms</div>
                    <div className="font-semibold text-foreground">5</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-xs text-muted-foreground">Complexity</div>
                    <div className="font-semibold text-foreground">Type B</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Interior Progress Feed */}
        <Card className="border-border/50 shadow-xl">
          <CardHeader>
            <CardTitle>Interior Progress Feed</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {progressFeed.map((item) => (
              <div
                key={item.id}
                className="flex gap-4 p-4 border border-border/50 rounded-xl hover:border-accent/50 transition-colors cursor-pointer"
                onClick={() => setSelectedImage(item.image)}
              >
                <div className="w-24 h-24 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.task}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex items-start justify-between">
                    <h4 className="font-semibold text-foreground">{item.task}</h4>
                    <Badge
                      variant={item.status === 'Completed' ? 'default' : 'secondary'}
                      className={
                        item.status === 'Completed'
                          ? 'bg-accent/10 text-accent'
                          : 'bg-secondary/10 text-secondary'
                      }
                    >
                      {item.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{item.notes}</p>
                  <p className="text-xs text-muted-foreground">{item.timestamp}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </main>

      {/* Image Modal */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Progress Photo</DialogTitle>
          </DialogHeader>
          {selectedImage && (
            <img
              src={selectedImage || "/placeholder.svg"}
              alt="Progress"
              className="w-full rounded-lg"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
