'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Plus, Trash2, ArrowLeft } from 'lucide-react'

type VillaType = {
  id: string
  typeName: string
  area: string
  floors: string
  rooms: string
  complexity: string
  count: string
}

export default function CreateProjectPage() {
  const router = useRouter()
  const [projectName, setProjectName] = useState('')
  const [location, setLocation] = useState('')
  const [villaTypes, setVillaTypes] = useState<VillaType[]>([
    {
      id: '1',
      typeName: '',
      area: '',
      floors: '',
      rooms: '',
      complexity: '',
      count: '',
    },
  ])

  const addVillaType = () => {
    setVillaTypes([
      ...villaTypes,
      {
        id: Date.now().toString(),
        typeName: '',
        area: '',
        floors: '',
        rooms: '',
        complexity: '',
        count: '',
      },
    ])
  }

  const removeVillaType = (id: string) => {
    if (villaTypes.length > 1) {
      setVillaTypes(villaTypes.filter((type) => type.id !== id))
    }
  }

  const updateVillaType = (id: string, field: keyof VillaType, value: string) => {
    setVillaTypes(
      villaTypes.map((type) =>
        type.id === id ? { ...type, [field]: value } : type
      )
    )
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Mock project creation - would save to backend in production
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8 px-6 max-w-5xl">
        <Button
          variant="ghost"
          onClick={() => router.push('/dashboard')}
          className="mb-6 gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Button>

        <Card className="border-border/50 shadow-xl">
          <CardHeader className="space-y-2 border-b border-border/50">
            <CardTitle className="text-3xl">Create New Project</CardTitle>
            <p className="text-muted-foreground">
              Set up a new construction project with villa types and specifications
            </p>
          </CardHeader>

          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Project Info */}
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-foreground">Project Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="projectName">Project Name *</Label>
                    <Input
                      id="projectName"
                      placeholder="e.g., SEDRA"
                      value={projectName}
                      onChange={(e) => setProjectName(e.target.value)}
                      className="h-11"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">Location *</Label>
                    <Input
                      id="location"
                      placeholder="e.g., Riyadh"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="h-11"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Villa Types */}
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-foreground">Villa Types</h3>
                  <Button type="button" onClick={addVillaType} variant="outline" className="gap-2">
                    <Plus className="w-4 h-4" />
                    Add Villa Type
                  </Button>
                </div>

                {villaTypes.map((villaType, index) => (
                  <Card key={villaType.id} className="border-border/50">
                    <CardContent className="p-6 space-y-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-foreground">Villa Type {index + 1}</h4>
                        {villaTypes.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeVillaType(villaType.id)}
                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label>Type Name *</Label>
                          <Input
                            placeholder="e.g., Type A"
                            value={villaType.typeName}
                            onChange={(e) =>
                              updateVillaType(villaType.id, 'typeName', e.target.value)
                            }
                            className="h-10"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Area (sqm) *</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 250"
                            value={villaType.area}
                            onChange={(e) =>
                              updateVillaType(villaType.id, 'area', e.target.value)
                            }
                            className="h-10"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Number of Floors *</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 2"
                            value={villaType.floors}
                            onChange={(e) =>
                              updateVillaType(villaType.id, 'floors', e.target.value)
                            }
                            className="h-10"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Number of Rooms *</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 5"
                            value={villaType.rooms}
                            onChange={(e) =>
                              updateVillaType(villaType.id, 'rooms', e.target.value)
                            }
                            className="h-10"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Structural Complexity *</Label>
                          <Select
                            value={villaType.complexity}
                            onValueChange={(value) =>
                              updateVillaType(villaType.id, 'complexity', value)
                            }
                          >
                            <SelectTrigger className="h-10">
                              <SelectValue placeholder="Select" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="A">A - Simple</SelectItem>
                              <SelectItem value="B">B - Moderate</SelectItem>
                              <SelectItem value="C">C - Complex</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label>Number of Villas *</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 11"
                            value={villaType.count}
                            onChange={(e) =>
                              updateVillaType(villaType.id, 'count', e.target.value)
                            }
                            className="h-10"
                            required
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="flex gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => router.push('/dashboard')}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90">
                  Create Project
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
