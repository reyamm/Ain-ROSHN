'use client'

import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { ArrowRight, Building2, Plus } from 'lucide-react'
import { useRouter } from 'next/navigation'

const projects = [
  {
    id: 1,
    name: 'Project 1 / SEDRA',
    location: 'Riyadh',
    progress: 67,
    status: 'on-track' as const,
  },
  {
    id: 2,
    name: 'Project 2 / AL WAHA',
    location: 'Jeddah',
    progress: 82,
    status: 'on-track' as const,
  },
  {
    id: 3,
    name: 'Project 3 / AL NARJIS',
    location: 'Riyadh',
    progress: 45,
    status: 'at-risk' as const,
  },
]

const kpis = [
  { label: 'Projects On Track', value: '78%', color: 'text-accent' },
  { label: 'At Risk', value: '47%', color: 'text-chart-3' },
  { label: 'Delayed', value: '27%', color: 'text-destructive' },
]

export default function DashboardPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 px-6 space-y-8">
        {/* Page Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground">Dashboard</h1>
            <p className="text-muted-foreground mt-2">Monitor all construction projects in real-time</p>
          </div>
          <Button 
            onClick={() => router.push('/create-project')}
            className="bg-primary hover:bg-primary/90 gap-2"
          >
            <Plus className="w-4 h-4" />
            Create Project
          </Button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {kpis.map((kpi, index) => (
            <Card key={index} className="border-border/50 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center space-y-2">
                <div className={`text-5xl font-bold ${kpi.color}`}>{kpi.value}</div>
                <div className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  {kpi.label}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Projects Section */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-foreground">Projects</h2>
            <button className="text-accent hover:text-accent/80 font-medium flex items-center gap-2 group">
              See all current projects
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <Card
                key={project.id}
                className="border-border/50 shadow-lg hover:shadow-xl transition-all cursor-pointer group"
                onClick={() => router.push(`/projects/${project.id}`)}
              >
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1 flex-1">
                      <h3 className="text-lg font-bold text-foreground group-hover:text-accent transition-colors">
                        {project.name}
                      </h3>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <Building2 className="w-3 h-3" />
                        {project.location}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium text-muted-foreground">Overall Progress</span>
                      <span className="font-bold text-foreground">{project.progress}%</span>
                    </div>
                    <Progress value={project.progress} className="h-3" />
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span
                      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold ${
                        project.status === 'on-track'
                          ? 'bg-accent/10 text-accent'
                          : 'bg-chart-3/10 text-chart-3'
                      }`}
                    >
                      {project.status === 'on-track' ? 'On Track' : 'At Risk'}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
